﻿
namespace WindowsFormsApp1
{
    partial class users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.OIB = new System.Windows.Forms.Label();
            this.txtUpisKorisnikPrezime = new System.Windows.Forms.TextBox();
            this.txtUpisKorisnikIme = new System.Windows.Forms.TextBox();
            this.txtUpisKorisnikId = new System.Windows.Forms.TextBox();
            this.btnUpisKorisnika = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.OIB);
            this.groupBox1.Controls.Add(this.txtUpisKorisnikPrezime);
            this.groupBox1.Controls.Add(this.txtUpisKorisnikIme);
            this.groupBox1.Controls.Add(this.txtUpisKorisnikId);
            this.groupBox1.Controls.Add(this.btnUpisKorisnika);
            this.groupBox1.Location = new System.Drawing.Point(216, 152);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(301, 177);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upisivanje korisnika";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Prezime";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ime";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // OIB
            // 
            this.OIB.AutoSize = true;
            this.OIB.Location = new System.Drawing.Point(7, 17);
            this.OIB.Name = "OIB";
            this.OIB.Size = new System.Drawing.Size(25, 13);
            this.OIB.TabIndex = 4;
            this.OIB.Text = "OIB";
            this.OIB.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtUpisKorisnikPrezime
            // 
            this.txtUpisKorisnikPrezime.Location = new System.Drawing.Point(6, 111);
            this.txtUpisKorisnikPrezime.Name = "txtUpisKorisnikPrezime";
            this.txtUpisKorisnikPrezime.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKorisnikPrezime.TabIndex = 3;
            // 
            // txtUpisKorisnikIme
            // 
            this.txtUpisKorisnikIme.Location = new System.Drawing.Point(6, 72);
            this.txtUpisKorisnikIme.Name = "txtUpisKorisnikIme";
            this.txtUpisKorisnikIme.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKorisnikIme.TabIndex = 2;
            // 
            // txtUpisKorisnikId
            // 
            this.txtUpisKorisnikId.Location = new System.Drawing.Point(7, 33);
            this.txtUpisKorisnikId.Name = "txtUpisKorisnikId";
            this.txtUpisKorisnikId.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKorisnikId.TabIndex = 1;
            this.txtUpisKorisnikId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnUpisKorisnika
            // 
            this.btnUpisKorisnika.Location = new System.Drawing.Point(163, 93);
            this.btnUpisKorisnika.Name = "btnUpisKorisnika";
            this.btnUpisKorisnika.Size = new System.Drawing.Size(95, 78);
            this.btnUpisKorisnika.TabIndex = 0;
            this.btnUpisKorisnika.Text = "upis";
            this.btnUpisKorisnika.UseVisualStyleBackColor = true;
            this.btnUpisKorisnika.Click += new System.EventHandler(this.btnUpisKorisnika_Click);
            // 
            // users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "users";
            this.Text = "users";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtUpisKorisnikPrezime;
        private System.Windows.Forms.TextBox txtUpisKorisnikIme;
        private System.Windows.Forms.TextBox txtUpisKorisnikId;
        private System.Windows.Forms.Button btnUpisKorisnika;
        private System.Windows.Forms.Label OIB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}