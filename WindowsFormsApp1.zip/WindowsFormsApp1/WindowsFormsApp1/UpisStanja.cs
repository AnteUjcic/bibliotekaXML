﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class UpisStanja : Form
    {
        List<Stanje> upisList = new List<Stanje>();
        public UpisStanja()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtStanjeKnjigeId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnStanjeKnjige_Click(object sender, EventArgs e)
        {
            string xml = "stanje.xml";
            Stanje stanjeK = new Stanje
            (Convert.ToInt32(txtStanjeKnjigeId.Text), 
            Convert.ToInt32(txtStanjeKnjigeKolicine.Text));

            upisList.Add(stanjeK);

            try
            {
                var knjigePath = XDocument.Load(xml);

                foreach (Stanje stanjeUpis in upisList)
                {
                    var Korisnik = new XElement("stanje",
                    new XElement("OSBN", stanjeUpis.OSBN1),
                    new XElement("Kolicine", stanjeUpis.Kolicine));
                    knjigePath.Root.Add(Korisnik);
                }
                knjigePath.Save(xml);
            }
            catch (Exception ex)
            {
                var upis = new XDocument(new XElement("stanje"));
                foreach (Stanje stanjeUpis in upisList)
                {
                    var Korisnik = new XElement("stanje",
                    new XElement("OSBN", stanjeUpis.OSBN1),
                    new XElement("Kolicine", stanjeUpis.Kolicine));
                    upis.Root.Add(Korisnik);
                }
                upis.Save(xml);

            }


                upisList.Clear();

            this.Close();
        }
    }
}
