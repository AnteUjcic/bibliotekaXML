﻿
namespace WindowsFormsApp1
{
    partial class picker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpisKnjiga = new System.Windows.Forms.Button();
            this.btnUpisStanja = new System.Windows.Forms.Button();
            this.btnUpisKorisnika = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUpisKnjiga
            // 
            this.btnUpisKnjiga.Location = new System.Drawing.Point(236, 85);
            this.btnUpisKnjiga.Name = "btnUpisKnjiga";
            this.btnUpisKnjiga.Size = new System.Drawing.Size(113, 86);
            this.btnUpisKnjiga.TabIndex = 0;
            this.btnUpisKnjiga.Text = "Upis knjiga";
            this.btnUpisKnjiga.UseVisualStyleBackColor = true;
            this.btnUpisKnjiga.Click += new System.EventHandler(this.btnUpisKnjiga_Click);
            // 
            // btnUpisStanja
            // 
            this.btnUpisStanja.Location = new System.Drawing.Point(355, 85);
            this.btnUpisStanja.Name = "btnUpisStanja";
            this.btnUpisStanja.Size = new System.Drawing.Size(113, 86);
            this.btnUpisStanja.TabIndex = 0;
            this.btnUpisStanja.Text = "Upis stanja";
            this.btnUpisStanja.UseVisualStyleBackColor = true;
            this.btnUpisStanja.Click += new System.EventHandler(this.btnUpisStanja_Click);
            // 
            // btnUpisKorisnika
            // 
            this.btnUpisKorisnika.Location = new System.Drawing.Point(117, 85);
            this.btnUpisKorisnika.Name = "btnUpisKorisnika";
            this.btnUpisKorisnika.Size = new System.Drawing.Size(113, 86);
            this.btnUpisKorisnika.TabIndex = 1;
            this.btnUpisKorisnika.Text = "Upis korisnika";
            this.btnUpisKorisnika.UseVisualStyleBackColor = true;
            this.btnUpisKorisnika.Click += new System.EventHandler(this.btnUpisKorisnika_Click);
            // 
            // picker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 269);
            this.Controls.Add(this.btnUpisKorisnika);
            this.Controls.Add(this.btnUpisStanja);
            this.Controls.Add(this.btnUpisKnjiga);
            this.Name = "picker";
            this.Text = "picker";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnUpisKnjiga;
        private System.Windows.Forms.Button btnUpisStanja;
        private System.Windows.Forms.Button btnUpisKorisnika;
    }
}