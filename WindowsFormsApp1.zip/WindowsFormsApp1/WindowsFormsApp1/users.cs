﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class users : Form
    {
        List<Korisnici> userList = new List<Korisnici>();
        
        
        
        public users()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnUpisKorisnika_Click(object sender, EventArgs e)
        {
            string xml = "user.xml";
            Korisnici user = new Korisnici(Convert.ToInt32
            (txtUpisKorisnikId.Text),
            txtUpisKorisnikIme.Text,
            txtUpisKorisnikPrezime.Text);
            userList.Add(user);
            //string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            //string exist= @"C:\Users\"+userName+ @"\Downloads\bibliotekaa-main\bibliotekaa-main\WindowsFormsApp1\WindowsFormsApp1\bin\Debug";
            //if (File.Exists(xml?exist)) {
            //
            // }
            try
            {
                var korisniciPath = XDocument.Load(xml);
                foreach (Korisnici userUpis in userList)
                {
                    var Korisnik = new XElement("Korisnik",
                    new XElement("ID", userUpis.OIB1),
                    new XElement("Ime", userUpis.Ime1),
                    new XElement("Prezime", userUpis.Prezime));
                    korisniciPath.Root.Add(Korisnik);
                }
            }
            catch (Exception ex)
            {
                var upis = new XDocument(new XElement("Korisnik"));
                foreach (Korisnici userUpis in userList)
                {
                    var Korisnik = new XElement("Korisnik",
                    new XElement("ID", userUpis.OIB1),
                    new XElement("Ime", userUpis.Ime1),
                    new XElement("Prezime", userUpis.Prezime));
                    upis.Root.Add(Korisnik);
                }
                upis.Save(xml);

            }
            userList.Clear();

            this.Close();
        }
    }
}
