﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class UpisKnjiga : Form
    {
        List<Knjige> upisKList = new List<Knjige>();
        List<Posudba> upisPList = new List<Posudba>();
        public UpisKnjiga()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtUpisKnjigeOSBN_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKnjigeNazivKnjige_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKnjigeNazivAutora_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKnjigePosudbaDatumPosudenja_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKnjigePosudbaDatumVracanja_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnKnjige_Click(object sender, EventArgs e)
        {
            string xml = "knjige.xml";
            Knjige upisK = new Knjige
            (Convert.ToInt32(txtUpisKnjigeOSBN.Text),
            txtUpisKnjigeNazivKnjige.Text, 
            txtUpisKnjigeNazivAutora.Text);

            upisKList.Add(upisK);

            try
            {
                var knjigePath = XDocument.Load(xml);

                foreach (Knjige stanjeUpis in upisKList)
                {
                    var Korisnik = new XElement("knjige",
                    new XElement("OSBN", stanjeUpis.OSBN1),
                    new XElement("Kolicine", stanjeUpis.NazivKnjige),
                    new XElement("Kolicine", stanjeUpis.NazivAutora));
                    knjigePath.Root.Add(Korisnik);
                }
                knjigePath.Save(xml);
            }
            catch (Exception ex)
            {
                var upis = new XDocument(new XElement("knjige"));
                foreach (Knjige stanjeUpis in upisKList)
                {
                    var Korisnik = new XElement("knjige",
                    new XElement("OSBN", stanjeUpis.OSBN1),
                    new XElement("Kolicine", stanjeUpis.NazivKnjige),
                    new XElement("Kolicine", stanjeUpis.NazivAutora));
                    upis.Root.Add(Korisnik);
                }
                upis.Save(xml);

            }


            upisKList.Clear();

            this.Close();
        }

        private void btnUpisPosudba_Click(object sender, EventArgs e)
        {
            string xml = "posudba.xml";
            Posudba upisP = new Posudba
           (Convert.ToDateTime(txtUpisKnjigePosudbaDatumPosudenja.Text),
            Convert.ToDateTime(txtUpisKnjigePosudbaDatumVracanja.Text));

            upisPList.Add(upisP);

            try
            {
                var knjigePath = XDocument.Load(xml);

                foreach (Posudba posdubaUpis in upisPList)
                {
                      var Korisnik = new XElement("posudba",
                    new XElement("DatumPosudbe", posdubaUpis.DatumPosudbe1),
                    new XElement("DatumVracanja", posdubaUpis.DatumVracanja));
                    knjigePath.Root.Add(Korisnik);
                }
                knjigePath.Save(xml);
            }
            catch (Exception ex)
            {
                var upis = new XDocument(new XElement("posudba"));
                foreach (Posudba posdubaUpis in upisPList)
                {
                    var Korisnik = new XElement("posudba",
                    new XElement("DatumPosudbe", posdubaUpis.DatumPosudbe1),
                    new XElement("DatumVracanja", posdubaUpis.DatumVracanja));
                    upis.Root.Add(Korisnik);
                    
                }
                upis.Save(xml);

            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}