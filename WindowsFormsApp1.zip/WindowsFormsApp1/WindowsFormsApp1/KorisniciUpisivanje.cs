﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;
using WindowsFormsApp1;

namespace AplikacijaBiblioteka
{
    public partial class upisivanjeKorisnika : Form
    {
      


        public upisivanjeKorisnika()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void btnKorisnik_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtUpisKorisnikId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKorisnikIme_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUpisKorisnikPrezime_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }
    }
}

