﻿namespace WindowsFormsApp1
{
    partial class UpisKnjiga
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnKnjige = new System.Windows.Forms.Button();
            this.txtUpisKnjigeOSBN = new System.Windows.Forms.TextBox();
            this.txtUpisKnjigeNazivKnjige = new System.Windows.Forms.TextBox();
            this.txtUpisKnjigeNazivAutora = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtUpisKnjigePosudbaDatumPosudenja = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpisPosudba = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUpisKnjigePosudbaDatumVracanja = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnKnjige
            // 
            this.btnKnjige.Location = new System.Drawing.Point(113, 81);
            this.btnKnjige.Name = "btnKnjige";
            this.btnKnjige.Size = new System.Drawing.Size(87, 63);
            this.btnKnjige.TabIndex = 2;
            this.btnKnjige.Text = "Upis";
            this.btnKnjige.UseVisualStyleBackColor = true;
            this.btnKnjige.Click += new System.EventHandler(this.btnKnjige_Click);
            // 
            // txtUpisKnjigeOSBN
            // 
            this.txtUpisKnjigeOSBN.Location = new System.Drawing.Point(7, 42);
            this.txtUpisKnjigeOSBN.Name = "txtUpisKnjigeOSBN";
            this.txtUpisKnjigeOSBN.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKnjigeOSBN.TabIndex = 3;
            this.txtUpisKnjigeOSBN.TextChanged += new System.EventHandler(this.txtUpisKnjigeOSBN_TextChanged);
            // 
            // txtUpisKnjigeNazivKnjige
            // 
            this.txtUpisKnjigeNazivKnjige.Location = new System.Drawing.Point(7, 81);
            this.txtUpisKnjigeNazivKnjige.Name = "txtUpisKnjigeNazivKnjige";
            this.txtUpisKnjigeNazivKnjige.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKnjigeNazivKnjige.TabIndex = 4;
            this.txtUpisKnjigeNazivKnjige.TextChanged += new System.EventHandler(this.txtUpisKnjigeNazivKnjige_TextChanged);
            // 
            // txtUpisKnjigeNazivAutora
            // 
            this.txtUpisKnjigeNazivAutora.Location = new System.Drawing.Point(7, 124);
            this.txtUpisKnjigeNazivAutora.Name = "txtUpisKnjigeNazivAutora";
            this.txtUpisKnjigeNazivAutora.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKnjigeNazivAutora.TabIndex = 5;
            this.txtUpisKnjigeNazivAutora.TextChanged += new System.EventHandler(this.txtUpisKnjigeNazivAutora_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "ID knjige(OSBN)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Naziv knjige";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Naziv autora";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtUpisKnjigeOSBN);
            this.groupBox1.Controls.Add(this.btnKnjige);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtUpisKnjigeNazivKnjige);
            this.groupBox1.Controls.Add(this.txtUpisKnjigeNazivAutora);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(76, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 182);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upis knjige";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtUpisKnjigePosudbaDatumPosudenja);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnUpisPosudba);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtUpisKnjigePosudbaDatumVracanja);
            this.groupBox2.Location = new System.Drawing.Point(282, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 182);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Posudba";
            // 
            // txtUpisKnjigePosudbaDatumPosudenja
            // 
            this.txtUpisKnjigePosudbaDatumPosudenja.Location = new System.Drawing.Point(6, 81);
            this.txtUpisKnjigePosudbaDatumPosudenja.Name = "txtUpisKnjigePosudbaDatumPosudenja";
            this.txtUpisKnjigePosudbaDatumPosudenja.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKnjigePosudbaDatumPosudenja.TabIndex = 3;
            this.txtUpisKnjigePosudbaDatumPosudenja.TextChanged += new System.EventHandler(this.txtUpisKnjigePosudbaDatumPosudenja_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Datum posuđenja";
            // 
            // btnUpisPosudba
            // 
            this.btnUpisPosudba.Location = new System.Drawing.Point(113, 81);
            this.btnUpisPosudba.Name = "btnUpisPosudba";
            this.btnUpisPosudba.Size = new System.Drawing.Size(87, 59);
            this.btnUpisPosudba.TabIndex = 1;
            this.btnUpisPosudba.Text = "Upis";
            this.btnUpisPosudba.UseVisualStyleBackColor = true;
            this.btnUpisPosudba.Click += new System.EventHandler(this.btnUpisPosudba_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Datum vraćanja";
            // 
            // txtUpisKnjigePosudbaDatumVracanja
            // 
            this.txtUpisKnjigePosudbaDatumVracanja.Location = new System.Drawing.Point(7, 120);
            this.txtUpisKnjigePosudbaDatumVracanja.Name = "txtUpisKnjigePosudbaDatumVracanja";
            this.txtUpisKnjigePosudbaDatumVracanja.Size = new System.Drawing.Size(100, 20);
            this.txtUpisKnjigePosudbaDatumVracanja.TabIndex = 4;
            this.txtUpisKnjigePosudbaDatumVracanja.TextChanged += new System.EventHandler(this.txtUpisKnjigePosudbaDatumVracanja_TextChanged);
            // 
            // UpisKnjiga
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UpisKnjiga";
            this.Text = "UpisKnjiga";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnKnjige;
        private System.Windows.Forms.TextBox txtUpisKnjigeOSBN;
        private System.Windows.Forms.TextBox txtUpisKnjigeNazivKnjige;
        private System.Windows.Forms.TextBox txtUpisKnjigeNazivAutora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtUpisKnjigePosudbaDatumPosudenja;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnUpisPosudba;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUpisKnjigePosudbaDatumVracanja;
    }
}