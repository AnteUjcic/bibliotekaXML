﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class picker : Form
    {

      
        public picker()
        {
            InitializeComponent();
        }

      

        private void btnUpisKorisnika_Click(object sender, EventArgs e)
        {
            users korov = new users();
            korov.ShowDialog();
        }

        private void btnUpisKnjiga_Click(object sender, EventArgs e)
        {
            UpisKnjiga upisKnjiga = new UpisKnjiga();
            upisKnjiga.ShowDialog();
        }

        private void btnUpisStanja_Click(object sender, EventArgs e)
        {
            UpisStanja upisStanja = new UpisStanja();
            upisStanja.ShowDialog();
        }
    }
}
